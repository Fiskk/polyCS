--
-- LimeSurvey Database Dump of `survey`
-- Date of Dump: 16-Sep-2013
--

-- --------------------------------------------------------

--
-- Table structure for table `lime2_answers`
--

DROP TABLE IF EXISTS `lime2_answers`;
CREATE TABLE `lime2_answers` (
  `qid` int(11) NOT NULL DEFAULT '0',
  `code` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `answer` text COLLATE utf8_unicode_ci NOT NULL,
  `assessment_value` int(11) NOT NULL DEFAULT '0',
  `sortorder` int(11) NOT NULL,
  `language` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `scale_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`,`code`,`language`,`scale_id`),
  KEY `answers_idx2` (`sortorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_answers`
--

INSERT INTO `lime2_answers` (`qid`,`code`,`answer`,`assessment_value`,`sortorder`,`language`,`scale_id`) VALUES
("2", "A1", "blue", "0", "1", "en", "0"),
("2", "A2", "green", "1", "2", "en", "0"),
("2", "A3", "red", "1", "3", "en", "0"),
("2", "A4", "i\'m not sure, I\'m blind", "1", "4", "en", "0");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_assessments`
--

DROP TABLE IF EXISTS `lime2_assessments`;
CREATE TABLE `lime2_assessments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT '0',
  `scope` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `gid` int(11) NOT NULL DEFAULT '0',
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `minimum` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `maximum` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`,`language`),
  KEY `assessments_idx2` (`sid`),
  KEY `assessments_idx3` (`gid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_assessments`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_conditions`
--

DROP TABLE IF EXISTS `lime2_conditions`;
CREATE TABLE `lime2_conditions` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL DEFAULT '0',
  `scenario` int(11) NOT NULL DEFAULT '1',
  `cqid` int(11) NOT NULL DEFAULT '0',
  `cfieldname` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `method` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`cid`),
  KEY `conditions_idx2` (`qid`),
  KEY `conditions_idx3` (`cqid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_conditions`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_defaultvalues`
--

DROP TABLE IF EXISTS `lime2_defaultvalues`;
CREATE TABLE `lime2_defaultvalues` (
  `qid` int(11) NOT NULL DEFAULT '0',
  `specialtype` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `scale_id` int(11) NOT NULL DEFAULT '0',
  `sqid` int(11) NOT NULL DEFAULT '0',
  `language` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `defaultvalue` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`qid`,`scale_id`,`language`,`specialtype`,`sqid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_defaultvalues`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_expression_errors`
--

DROP TABLE IF EXISTS `lime2_expression_errors`;
CREATE TABLE `lime2_expression_errors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `errortime` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `qid` int(11) DEFAULT NULL,
  `gseq` int(11) DEFAULT NULL,
  `qseq` int(11) DEFAULT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `eqn` text COLLATE utf8_unicode_ci,
  `prettyprint` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_expression_errors`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_failed_login_attempts`
--

DROP TABLE IF EXISTS `lime2_failed_login_attempts`;
CREATE TABLE `lime2_failed_login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `last_attempt` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `number_attempts` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_failed_login_attempts`
--

INSERT INTO `lime2_failed_login_attempts` (`id`,`ip`,`last_attempt`,`number_attempts`) VALUES
("6", "", "2012-01-23 15:23:04", "1"),
("3", "", "2012-01-20 00:24:24", "1"),
("4", "", "2012-01-20 00:24:26", "1"),
("5", "", "2012-01-20 00:24:31", "1"),
("7", "", "2012-01-23 15:23:06", "1"),
("8", "", "2012-01-23 15:23:09", "1"),
("9", "", "2012-01-23 15:23:10", "1"),
("10", "", "2012-01-23 15:23:11", "1"),
("11", "", "2012-01-23 15:23:15", "1"),
("12", "", "2012-01-23 15:23:21", "1"),
("13", "", "2012-01-24 14:54:03", "1"),
("14", "", "2012-01-24 14:54:07", "1");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_groups`
--

DROP TABLE IF EXISTS `lime2_groups`;
CREATE TABLE `lime2_groups` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT '0',
  `group_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `group_order` int(11) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `language` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `randomization_group` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `grelevance` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`gid`,`language`),
  KEY `groups_idx2` (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_groups`
--

INSERT INTO `lime2_groups` (`gid`,`sid`,`group_name`,`group_order`,`description`,`language`,`randomization_group`,`grelevance`) VALUES
("1", "91467", "Test", "0", "", "en", "", NULL),
("2", "559245", "test question group", "1", "test question group", "en", "", "");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_labels`
--

DROP TABLE IF EXISTS `lime2_labels`;
CREATE TABLE `lime2_labels` (
  `lid` int(11) NOT NULL DEFAULT '0',
  `code` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` text COLLATE utf8_unicode_ci,
  `sortorder` int(11) NOT NULL,
  `assessment_value` int(11) NOT NULL DEFAULT '0',
  `language` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  PRIMARY KEY (`lid`,`sortorder`,`language`),
  KEY `labels_code_idx` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_labels`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_labelsets`
--

DROP TABLE IF EXISTS `lime2_labelsets`;
CREATE TABLE `lime2_labelsets` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `label_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `languages` varchar(200) COLLATE utf8_unicode_ci DEFAULT 'en',
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_labelsets`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_participant_attribute`
--

DROP TABLE IF EXISTS `lime2_participant_attribute`;
CREATE TABLE `lime2_participant_attribute` (
  `participant_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`participant_id`,`attribute_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_participant_attribute`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_participant_attribute_names`
--

DROP TABLE IF EXISTS `lime2_participant_attribute_names`;
CREATE TABLE `lime2_participant_attribute_names` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_type` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `visible` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`attribute_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_participant_attribute_names`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_participant_attribute_names_lang`
--

DROP TABLE IF EXISTS `lime2_participant_attribute_names_lang`;
CREATE TABLE `lime2_participant_attribute_names_lang` (
  `attribute_id` int(11) NOT NULL,
  `attribute_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lang` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`attribute_id`,`lang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_participant_attribute_names_lang`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_participant_attribute_values`
--

DROP TABLE IF EXISTS `lime2_participant_attribute_values`;
CREATE TABLE `lime2_participant_attribute_values` (
  `attribute_id` int(11) NOT NULL,
  `value_id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`value_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_participant_attribute_values`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_participant_shares`
--

DROP TABLE IF EXISTS `lime2_participant_shares`;
CREATE TABLE `lime2_participant_shares` (
  `participant_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `share_uid` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `can_edit` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`participant_id`,`share_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_participant_shares`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_participants`
--

DROP TABLE IF EXISTS `lime2_participants`;
CREATE TABLE `lime2_participants` (
  `participant_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `firstname` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blacklisted` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `owner_uid` int(11) NOT NULL,
  PRIMARY KEY (`participant_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_participants`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_question_attributes`
--

DROP TABLE IF EXISTS `lime2_question_attributes`;
CREATE TABLE `lime2_question_attributes` (
  `qaid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL DEFAULT '0',
  `attribute` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `language` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`qaid`),
  KEY `question_attributes_idx2` (`qid`),
  KEY `question_attributes_idx3` (`attribute`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_question_attributes`
--

INSERT INTO `lime2_question_attributes` (`qaid`,`qid`,`attribute`,`value`,`language`) VALUES
("1", "1", "display_columns", "1", NULL),
("2", "1", "hidden", "0", NULL),
("3", "1", "page_break", "0", NULL),
("4", "1", "public_statistics", "0", NULL),
("5", "1", "scale_export", "0", NULL),
("6", "1", "random_group", "", NULL),
("7", "2", "random_order", "1", NULL);


-- --------------------------------------------------------

--
-- Table structure for table `lime2_questions`
--

DROP TABLE IF EXISTS `lime2_questions`;
CREATE TABLE `lime2_questions` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `parent_qid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `gid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'T',
  `title` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `question` text COLLATE utf8_unicode_ci NOT NULL,
  `preg` text COLLATE utf8_unicode_ci,
  `help` text COLLATE utf8_unicode_ci,
  `other` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `mandatory` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `question_order` int(11) NOT NULL,
  `language` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `scale_id` int(11) NOT NULL DEFAULT '0',
  `same_default` int(11) NOT NULL DEFAULT '0',
  `relevance` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`qid`,`language`),
  KEY `questions_idx2` (`sid`),
  KEY `questions_idx3` (`gid`),
  KEY `parent_qid_idx` (`parent_qid`),
  KEY `questions_idx4` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_questions`
--

INSERT INTO `lime2_questions` (`qid`,`parent_qid`,`sid`,`gid`,`type`,`title`,`question`,`preg`,`help`,`other`,`mandatory`,`question_order`,`language`,`scale_id`,`same_default`,`relevance`) VALUES
("1", "0", "91467", "1", "G", "Gender", "What is your gender?", "", "", "N", "Y", "0", "en", "0", "0", NULL),
("2", "0", "559245", "2", "L", "1", "What color is the sky?", "", "", "N", "N", "1", "en", "0", "0", "2");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_quota`
--

DROP TABLE IF EXISTS `lime2_quota`;
CREATE TABLE `lime2_quota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `qlimit` int(11) DEFAULT NULL,
  `action` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `autoload_url` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `quota_idx2` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_quota`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_quota_languagesettings`
--

DROP TABLE IF EXISTS `lime2_quota_languagesettings`;
CREATE TABLE `lime2_quota_languagesettings` (
  `quotals_id` int(11) NOT NULL AUTO_INCREMENT,
  `quotals_quota_id` int(11) NOT NULL,
  `quotals_language` varchar(45) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `quotals_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quotals_message` text COLLATE utf8_unicode_ci NOT NULL,
  `quotals_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quotals_urldescrip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`quotals_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_quota_languagesettings`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_quota_members`
--

DROP TABLE IF EXISTS `lime2_quota_members`;
CREATE TABLE `lime2_quota_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `qid` int(11) DEFAULT NULL,
  `quota_id` int(11) DEFAULT NULL,
  `code` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`,`qid`,`quota_id`,`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_quota_members`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_saved_control`
--

DROP TABLE IF EXISTS `lime2_saved_control`;
CREATE TABLE `lime2_saved_control` (
  `scid` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT '0',
  `srid` int(11) NOT NULL DEFAULT '0',
  `identifier` text COLLATE utf8_unicode_ci NOT NULL,
  `access_code` text COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(320) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip` text COLLATE utf8_unicode_ci NOT NULL,
  `saved_thisstep` text COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `saved_date` datetime NOT NULL,
  `refurl` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`scid`),
  KEY `saved_control_idx2` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_saved_control`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_sessions`
--

DROP TABLE IF EXISTS `lime2_sessions`;
CREATE TABLE `lime2_sessions` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `expire` int(11) DEFAULT NULL,
  `data` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_settings_global`
--

DROP TABLE IF EXISTS `lime2_settings_global`;
CREATE TABLE `lime2_settings_global` (
  `stg_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `stg_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`stg_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_settings_global`
--

INSERT INTO `lime2_settings_global` (`stg_name`,`stg_value`) VALUES
("DBVersion", "164"),
("SessionName", "ls26632282321831999556"),
("force_ssl", "on"),
("showXquestions", "choose"),
("showgroupinfo", "choose"),
("showqnumcode", "choose"),
("updateavailable", "1"),
("updatelastcheck", "2013-09-16 20:34:42"),
("siteadminbounce", "webmaster@cs.sunyit.edu"),
("defaultlang", "en"),
("restrictToLanguages", ""),
("sitename", "CS Survey"),
("updatecheckperiod", "7"),
("defaulthtmleditormode", "inline"),
("defaultquestionselectormode", "default"),
("defaulttemplateeditormode", "default"),
("defaulttemplate", "copy_of_default"),
("admintheme", "gringegreen"),
("adminthemeiconsize", "32"),
("emailmethod", "mail"),
("emailsmtphost", ""),
("emailsmtppassword", ""),
("bounceaccounthost", ""),
("bounceaccounttype", "off"),
("bounceencryption", ""),
("bounceaccountuser", ""),
("bounceaccountpass", ""),
("emailsmtpssl", ""),
("emailsmtpdebug", "0"),
("emailsmtpuser", ""),
("filterxsshtml", "1"),
("siteadminemail", "webmaster@cs.sunyit.edu"),
("siteadminname", "CS Dept. Webmaster"),
("shownoanswer", "1"),
("repeatheadings", "25"),
("maxemails", "50"),
("iSessionExpirationTime", "7200"),
("ipInfoDbAPIKey", ""),
("googleMapsAPIKey", ""),
("googleanalyticsapikey", ""),
("googletranslateapikey", ""),
("surveyPreview_require_Auth", "1"),
("RPCInterface", "off"),
("timeadjust", "+0 minutes"),
("usercontrolSameGroupPolicy", "1"),
("updatebuild", "130913"),
("updateversion", "2.00+"),
("usepdfexport", "0"),
("addTitleToLinks", ""),
("sessionlifetime", "3600"),
("updatekey", "LIMESURVEYUPDATE");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_survey_91467`
--

DROP TABLE IF EXISTS `lime2_survey_91467`;
CREATE TABLE `lime2_survey_91467` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `submitdate` datetime DEFAULT NULL,
  `lastpage` int(11) DEFAULT NULL,
  `startlanguage` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `91467X1X1` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_survey_91467`
--

INSERT INTO `lime2_survey_91467` (`id`,`submitdate`,`lastpage`,`startlanguage`,`token`,`91467X1X1`) VALUES
("1", "2012-01-25 09:37:09", "2", "en", "", "M"),
("2", "1980-01-01 00:00:00", "1", "en", NULL, "M"),
("3", "1980-01-01 00:00:00", "1", "en", NULL, "M"),
("4", "1980-01-01 00:00:00", "1", "en", NULL, "M");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_survey_links`
--

DROP TABLE IF EXISTS `lime2_survey_links`;
CREATE TABLE `lime2_survey_links` (
  `participant_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `token_id` int(11) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_invited` datetime DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  PRIMARY KEY (`participant_id`,`token_id`,`survey_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_survey_links`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_survey_permissions`
--

DROP TABLE IF EXISTS `lime2_survey_permissions`;
CREATE TABLE `lime2_survey_permissions` (
  `sid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `permission` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `create_p` int(11) NOT NULL DEFAULT '0',
  `read_p` int(11) NOT NULL DEFAULT '0',
  `update_p` int(11) NOT NULL DEFAULT '0',
  `delete_p` int(11) NOT NULL DEFAULT '0',
  `import_p` int(11) NOT NULL DEFAULT '0',
  `export_p` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`,`uid`,`permission`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_survey_permissions`
--

INSERT INTO `lime2_survey_permissions` (`sid`,`uid`,`permission`,`create_p`,`read_p`,`update_p`,`delete_p`,`import_p`,`export_p`) VALUES
("91467", "3", "assessments", "1", "1", "1", "1", "0", "0"),
("91467", "3", "translations", "0", "1", "1", "0", "0", "0"),
("91467", "3", "quotas", "1", "1", "1", "1", "0", "0"),
("91467", "3", "responses", "1", "1", "1", "1", "1", "1"),
("91467", "3", "statistics", "0", "1", "0", "0", "0", "0"),
("91467", "3", "surveyactivation", "0", "0", "1", "0", "0", "0"),
("91467", "3", "surveycontent", "1", "1", "1", "1", "1", "1"),
("91467", "3", "survey", "0", "1", "0", "1", "0", "0"),
("91467", "3", "surveylocale", "0", "1", "1", "0", "0", "0"),
("91467", "3", "surveysecurity", "1", "1", "1", "1", "0", "0"),
("91467", "3", "surveysettings", "0", "1", "1", "0", "0", "0"),
("91467", "3", "tokens", "1", "1", "1", "1", "1", "1"),
("559245", "6", "assessments", "1", "1", "1", "1", "0", "0"),
("559245", "6", "translations", "0", "1", "1", "0", "0", "0"),
("559245", "6", "quotas", "1", "1", "1", "1", "0", "0"),
("559245", "6", "responses", "1", "1", "1", "1", "1", "1"),
("559245", "6", "statistics", "0", "1", "0", "0", "0", "0"),
("559245", "6", "surveyactivation", "0", "0", "1", "0", "0", "0"),
("559245", "6", "surveycontent", "1", "1", "1", "1", "1", "1"),
("559245", "6", "survey", "0", "1", "0", "1", "0", "0"),
("559245", "6", "surveylocale", "0", "1", "1", "0", "0", "0"),
("559245", "6", "surveysecurity", "1", "1", "1", "1", "0", "0"),
("559245", "6", "surveysettings", "0", "1", "1", "0", "0", "0"),
("559245", "6", "tokens", "1", "1", "1", "1", "1", "1");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_survey_url_parameters`
--

DROP TABLE IF EXISTS `lime2_survey_url_parameters`;
CREATE TABLE `lime2_survey_url_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL,
  `parameter` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `targetqid` int(11) DEFAULT NULL,
  `targetsqid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_survey_url_parameters`
--


-- --------------------------------------------------------

--
-- Table structure for table `lime2_surveys`
--

DROP TABLE IF EXISTS `lime2_surveys`;
CREATE TABLE `lime2_surveys` (
  `sid` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `admin` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `expires` datetime DEFAULT NULL,
  `startdate` datetime DEFAULT NULL,
  `adminemail` varchar(320) COLLATE utf8_unicode_ci DEFAULT NULL,
  `anonymized` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `faxto` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `format` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `savetimings` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT 'default',
  `language` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `additional_languages` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datestamp` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `usecookie` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `allowregister` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `allowsave` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `autonumber_start` int(11) NOT NULL DEFAULT '0',
  `autoredirect` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `allowprev` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `printanswers` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ipaddr` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `refurl` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `datecreated` date DEFAULT NULL,
  `publicstatistics` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `publicgraphs` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `listpublic` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `htmlemail` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tokenanswerspersistence` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `assessments` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `usecaptcha` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `usetokens` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `bounce_email` varchar(320) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attributedescriptions` text COLLATE utf8_unicode_ci,
  `emailresponseto` text COLLATE utf8_unicode_ci,
  `emailnotificationto` text COLLATE utf8_unicode_ci,
  `tokenlength` int(11) NOT NULL DEFAULT '15',
  `showxquestions` varchar(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `showgroupinfo` varchar(1) COLLATE utf8_unicode_ci DEFAULT 'B',
  `shownoanswer` varchar(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `showqnumcode` varchar(1) COLLATE utf8_unicode_ci DEFAULT 'X',
  `bouncetime` int(11) DEFAULT NULL,
  `bounceprocessing` varchar(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `bounceaccounttype` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bounceaccounthost` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bounceaccountpass` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bounceaccountencryption` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bounceaccountuser` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `showwelcome` varchar(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `showprogress` varchar(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `allowjumps` varchar(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `navigationdelay` int(11) NOT NULL DEFAULT '0',
  `nokeyboard` varchar(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `alloweditaftercompletion` varchar(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `googleanalyticsstyle` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `googleanalyticsapikey` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sendconfirmation` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_surveys`
--

INSERT INTO `lime2_surveys` (`sid`,`owner_id`,`admin`,`active`,`expires`,`startdate`,`adminemail`,`anonymized`,`faxto`,`format`,`savetimings`,`template`,`language`,`additional_languages`,`datestamp`,`usecookie`,`allowregister`,`allowsave`,`autonumber_start`,`autoredirect`,`allowprev`,`printanswers`,`ipaddr`,`refurl`,`datecreated`,`publicstatistics`,`publicgraphs`,`listpublic`,`htmlemail`,`tokenanswerspersistence`,`assessments`,`usecaptcha`,`usetokens`,`bounce_email`,`attributedescriptions`,`emailresponseto`,`emailnotificationto`,`tokenlength`,`showxquestions`,`showgroupinfo`,`shownoanswer`,`showqnumcode`,`bouncetime`,`bounceprocessing`,`bounceaccounttype`,`bounceaccounthost`,`bounceaccountpass`,`bounceaccountencryption`,`bounceaccountuser`,`showwelcome`,`showprogress`,`allowjumps`,`navigationdelay`,`nokeyboard`,`alloweditaftercompletion`,`googleanalyticsstyle`,`googleanalyticsapikey`,`sendconfirmation`) VALUES
("91467", "2", "autouser", "Y", NULL, NULL, "your-email@example.net", "N", "", "G", "N", "default", "en", "", "N", "N", "N", "Y", "0", "N", "N", "N", "N", "N", "2012-01-25", "N", "N", "Y", "Y", "N", "N", "D", "N", "webmaster@cs.sunyit.edu", "a:0:{}", "", "", "15", "Y", "B", "Y", "X", NULL, "N", NULL, NULL, NULL, NULL, NULL, "Y", "Y", "N", "0", "N", "N", NULL, NULL, "Y"),
("559245", "6", "vanderjr", "N", NULL, NULL, "vanderjr@cs.sunyit.edu", "N", "", "G", "N", "basic", "en", NULL, "N", "N", "N", "Y", "0", "N", "N", "N", "N", "N", "2013-09-10", "N", "N", "Y", "Y", "N", "N", "D", "N", "vanderjr@cs.sunyit.edu", "a:0:{}", "", "", "15", "Y", "B", "Y", "X", NULL, "N", NULL, NULL, NULL, NULL, NULL, "Y", "Y", "N", "0", "N", "N", NULL, NULL, "Y");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_surveys_languagesettings`
--

DROP TABLE IF EXISTS `lime2_surveys_languagesettings`;
CREATE TABLE `lime2_surveys_languagesettings` (
  `surveyls_survey_id` int(11) NOT NULL,
  `surveyls_language` varchar(45) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `surveyls_title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `surveyls_description` text COLLATE utf8_unicode_ci,
  `surveyls_welcometext` text COLLATE utf8_unicode_ci,
  `surveyls_endtext` text COLLATE utf8_unicode_ci,
  `surveyls_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surveyls_urldescription` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surveyls_email_invite_subj` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surveyls_email_invite` text COLLATE utf8_unicode_ci,
  `surveyls_email_remind_subj` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surveyls_email_remind` text COLLATE utf8_unicode_ci,
  `surveyls_email_register_subj` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surveyls_email_register` text COLLATE utf8_unicode_ci,
  `surveyls_email_confirm_subj` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surveyls_email_confirm` text COLLATE utf8_unicode_ci,
  `surveyls_dateformat` int(11) NOT NULL DEFAULT '1',
  `email_admin_notification_subj` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_admin_notification` text COLLATE utf8_unicode_ci,
  `email_admin_responses_subj` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_admin_responses` text COLLATE utf8_unicode_ci,
  `surveyls_numberformat` int(11) NOT NULL DEFAULT '0',
  `surveyls_attributecaptions` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`surveyls_survey_id`,`surveyls_language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_surveys_languagesettings`
--

INSERT INTO `lime2_surveys_languagesettings` (`surveyls_survey_id`,`surveyls_language`,`surveyls_title`,`surveyls_description`,`surveyls_welcometext`,`surveyls_endtext`,`surveyls_url`,`surveyls_urldescription`,`surveyls_email_invite_subj`,`surveyls_email_invite`,`surveyls_email_remind_subj`,`surveyls_email_remind`,`surveyls_email_register_subj`,`surveyls_email_register`,`surveyls_email_confirm_subj`,`surveyls_email_confirm`,`surveyls_dateformat`,`email_admin_notification_subj`,`email_admin_notification`,`email_admin_responses_subj`,`email_admin_responses`,`surveyls_numberformat`,`surveyls_attributecaptions`) VALUES
("91467", "en", "Test Survey", "", "Hello", "", "", "", "Invitation to participate in a survey", "Dear {FIRSTNAME},<br /><br />you have been invited to participate in a survey.<br /><br />The survey is titled:<br />\"{SURVEYNAME}\"<br /><br />\"{SURVEYDESCRIPTION}\"<br /><br />To participate, please click on the link below.<br /><br />Sincerely,<br /><br />{ADMINNAME} ({ADMINEMAIL})<br /><br />----------------------------------------------<br />Click here to do the survey:<br />{SURVEYURL}<br /><br />If you do not want to participate in this survey and don\'t want to receive any more invitations please click the following link:<br />{OPTOUTURL}", "Reminder to participate in a survey", "Dear {FIRSTNAME},<br /><br />Recently we invited you to participate in a survey.<br /><br />We note that you have not yet completed the survey, and wish to remind you that the survey is still available should you wish to take part.<br /><br />The survey is titled:<br />\"{SURVEYNAME}\"<br /><br />\"{SURVEYDESCRIPTION}\"<br /><br />To participate, please click on the link below.<br /><br />Sincerely,<br /><br />{ADMINNAME} ({ADMINEMAIL})<br /><br />----------------------------------------------<br />Click here to do the survey:<br />{SURVEYURL}<br /><br />If you do not want to participate in this survey and don\'t want to receive any more invitations please click the following link:<br />{OPTOUTURL}", "Survey registration confirmation", "Dear {FIRSTNAME},<br /><br />You, or someone using your email address, have registered to participate in an online survey titled {SURVEYNAME}.<br /><br />To complete this survey, click on the following URL:<br /><br />{SURVEYURL}<br /><br />If you have any questions about this survey, or if you did not register to participate and believe this email is in error, please contact {ADMINNAME} at {ADMINEMAIL}.", "Confirmation of your participation in our survey", "Dear {FIRSTNAME},<br /><br />this email is to confirm that you have completed the survey titled {SURVEYNAME} and your response has been saved. Thank you for participating.<br /><br />If you have any further questions about this email, please contact {ADMINNAME} on {ADMINEMAIL}.<br /><br />Sincerely,<br /><br />{ADMINNAME}", "9", "Response submission for survey {SURVEYNAME}", "Hello,<br /><br />A new response was submitted for your survey \'{SURVEYNAME}\'.<br /><br />Click the following link to reload the survey:<br />{RELOADURL}<br /><br />Click the following link to see the individual response:<br />{VIEWRESPONSEURL}<br /><br />Click the following link to edit the individual response:<br />{EDITRESPONSEURL}<br /><br />View statistics by clicking here:<br />{STATISTICSURL}", "Response submission for survey {SURVEYNAME} with results", "<style type=\"text/css\">\n                                                .printouttable {\n                                                  margin:1em auto;\n                                                }\n                                                .printouttable th {\n                                                  text-align: center;\n                                                }\n                                                .printouttable td {\n                                                  border-color: #ddf #ddf #ddf #ddf;\n                                                  border-style: solid;\n                                                  border-width: 1px;\n                                                  padding:0.1em 1em 0.1em 0.5em;\n                                                }\n\n                                                .printouttable td:first-child {\n                                                  font-weight: 700;\n                                                  text-align: right;\n                                                  padding-right: 5px;\n                                                  padding-left: 5px;\n\n                                                }\n                                                .printouttable .printanswersquestion td{\n                                                  background-color:#F7F8FF;\n                                                }\n\n                                                .printouttable .printanswersquestionhead td{\n                                                  text-align: left;\n                                                  background-color:#ddf;\n                                                }\n\n                                                .printouttable .printanswersgroup td{\n                                                  text-align: center;        \n                                                  font-weight:bold;\n                                                  padding-top:1em;\n                                                }\n                                                </style>Hello,<br /><br />A new response was submitted for your survey \'{SURVEYNAME}\'.<br /><br />Click the following link to reload the survey:<br />{RELOADURL}<br /><br />Click the following link to see the individual response:<br />{VIEWRESPONSEURL}<br /><br />Click the following link to edit the individual response:<br />{EDITRESPONSEURL}<br /><br />View statistics by clicking here:<br />{STATISTICSURL}<br /><br /><br />The following answers were given by the participant:<br />{ANSWERTABLE}", "0", "a:0:{}"),
("559245", "en", "test", "A test survey", "", "", "", "", "Invitation to participate in a survey", "Dear {FIRSTNAME},\n\nyou have been invited to participate in a survey.\n\nThe survey is titled:\n\"{SURVEYNAME}\"\n\n\"{SURVEYDESCRIPTION}\"\n\nTo participate, please click on the link below.\n\nSincerely,\n\n{ADMINNAME} ({ADMINEMAIL})\n\n----------------------------------------------\nClick here to do the survey:\n{SURVEYURL}\n\nIf you do not want to participate in this survey and don\'t want to receive any more invitations please click the following link:\n{OPTOUTURL}\n\nIf you are blacklisted but want to participate in this survey and want to receive invitations please click the following link:\n{OPTINURL}", "Reminder to participate in a survey", "Dear {FIRSTNAME},\n\nRecently we invited you to participate in a survey.\n\nWe note that you have not yet completed the survey, and wish to remind you that the survey is still available should you wish to take part.\n\nThe survey is titled:\n\"{SURVEYNAME}\"\n\n\"{SURVEYDESCRIPTION}\"\n\nTo participate, please click on the link below.\n\nSincerely,\n\n{ADMINNAME} ({ADMINEMAIL})\n\n----------------------------------------------\nClick here to do the survey:\n{SURVEYURL}\n\nIf you do not want to participate in this survey and don\'t want to receive any more invitations please click the following link:\n{OPTOUTURL}", "Survey registration confirmation", "Dear {FIRSTNAME},\n\nYou, or someone using your email address, have registered to participate in an online survey titled {SURVEYNAME}.\n\nTo complete this survey, click on the following URL:\n\n{SURVEYURL}\n\nIf you have any questions about this survey, or if you did not register to participate and believe this email is in error, please contact {ADMINNAME} at {ADMINEMAIL}.", "Confirmation of your participation in our survey", "Dear {FIRSTNAME},\n\nthis email is to confirm that you have completed the survey titled {SURVEYNAME} and your response has been saved. Thank you for participating.\n\nIf you have any further questions about this email, please contact {ADMINNAME} on {ADMINEMAIL}.\n\nSincerely,\n\n{ADMINNAME}", "9", "Response submission for survey {SURVEYNAME}", "Hello,\n\nA new response was submitted for your survey \'{SURVEYNAME}\'.\n\nClick the following link to reload the survey:\n{RELOADURL}\n\nClick the following link to see the individual response:\n{VIEWRESPONSEURL}\n\nClick the following link to edit the individual response:\n{EDITRESPONSEURL}\n\nView statistics by clicking here:\n{STATISTICSURL}", "Response submission for survey {SURVEYNAME} with results", "Hello,\n\nA new response was submitted for your survey \'{SURVEYNAME}\'.\n\nClick the following link to reload the survey:\n{RELOADURL}\n\nClick the following link to see the individual response:\n{VIEWRESPONSEURL}\n\nClick the following link to edit the individual response:\n{EDITRESPONSEURL}\n\nView statistics by clicking here:\n{STATISTICSURL}\n\n\nThe following answers were given by the participant:\n{ANSWERTABLE}", "0", "a:0:{}");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_templates`
--

DROP TABLE IF EXISTS `lime2_templates`;
CREATE TABLE `lime2_templates` (
  `folder` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`folder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_templates`
--

INSERT INTO `lime2_templates` (`folder`,`creator`) VALUES
("basic", "5"),
("bluengrey", "5"),
("citronade", "5"),
("clear_logo", "5"),
("default", "5"),
("eirenicon", "5"),
("limespired", "5"),
("mint_idea", "5"),
("sherpa", "5"),
("vallendar", "5");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_templates_rights`
--

DROP TABLE IF EXISTS `lime2_templates_rights`;
CREATE TABLE `lime2_templates_rights` (
  `uid` int(11) NOT NULL,
  `folder` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `use` int(11) NOT NULL,
  PRIMARY KEY (`uid`,`folder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_templates_rights`
--

INSERT INTO `lime2_templates_rights` (`uid`,`folder`,`use`) VALUES
("5", "default", "1"),
("4", "basic", "1"),
("4", "default", "1"),
("3", "basic", "1"),
("3", "default", "1"),
("2", "basic", "1"),
("2", "default", "1"),
("5", "basic", "1"),
("6", "default", "1"),
("6", "basic", "1");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_user_groups`
--

DROP TABLE IF EXISTS `lime2_user_groups`;
CREATE TABLE `lime2_user_groups` (
  `ugid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`ugid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_user_groups`
--

INSERT INTO `lime2_user_groups` (`ugid`,`name`,`description`,`owner_id`) VALUES
("1", "Admins", "Administrators", "1");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_user_in_groups`
--

DROP TABLE IF EXISTS `lime2_user_in_groups`;
CREATE TABLE `lime2_user_in_groups` (
  `ugid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`ugid`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_user_in_groups`
--

INSERT INTO `lime2_user_in_groups` (`ugid`,`uid`) VALUES
("1", "1"),
("1", "2");


-- --------------------------------------------------------

--
-- Table structure for table `lime2_users`
--

DROP TABLE IF EXISTS `lime2_users`;
CREATE TABLE `lime2_users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `users_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` blob NOT NULL,
  `full_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL,
  `lang` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(320) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_survey` int(11) NOT NULL DEFAULT '0',
  `create_user` int(11) NOT NULL DEFAULT '0',
  `delete_user` int(11) NOT NULL DEFAULT '0',
  `superadmin` int(11) NOT NULL DEFAULT '0',
  `configurator` int(11) NOT NULL DEFAULT '0',
  `manage_template` int(11) NOT NULL DEFAULT '0',
  `manage_label` int(11) NOT NULL DEFAULT '0',
  `htmleditormode` varchar(7) COLLATE utf8_unicode_ci DEFAULT 'default',
  `dateformat` int(11) NOT NULL DEFAULT '1',
  `templateeditormode` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `questionselectormode` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `participant_panel` int(11) NOT NULL DEFAULT '0',
  `one_time_pw` blob,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `users_name` (`users_name`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lime2_users`
--

INSERT INTO `lime2_users` (`uid`,`users_name`,`password`,`full_name`,`parent_id`,`lang`,`email`,`create_survey`,`create_user`,`delete_user`,`superadmin`,`configurator`,`manage_template`,`manage_label`,`htmleditormode`,`dateformat`,`templateeditormode`,`questionselectormode`,`participant_panel`,`one_time_pw`) VALUES
("1", "admin", "d27d857954e68b6914905ed6ef16399c73f73ebab97f3e50fa0d1272c2cc602f", "admin", "0", "en", "admins@cs.sunyit.edu", "1", "1", "1", "1", "1", "1", "1", "default", "1", "default", "default", "0", NULL),
("2", "halberl", "bcb06b61cfb6931946acab9bbaf0b0bd3533e9c34553f4e65e49ce66623f574e", "halberl", "1", "en", "halberl@cs.sunyit.edu", "1", "1", "1", "1", "1", "1", "1", "default", "1", "default", "default", "1", NULL),
("3", "brennap", "28a4e5f31026bd2a0ff1134689fe8be2c2ccf7a751ecf1d3562167799a9183d2", "brennap", "1", "en", "brennap@cs.sunyit.edu", "1", "1", "1", "1", "1", "1", "1", "default", "1", "default", "default", "1", NULL),
("4", "merantn", "15944131d8bd2a560763731148a79a1ff687173e79f1ca37ba533c838b975456", "merantn", "1", "en", "merantn@cs.sunyit.edu", "1", "1", "1", "1", "1", "1", "1", "default", "1", "default", "default", "0", NULL),
("5", "nick", "66607345fbf6858f518c81dcfde5975e472a96397c9985723a54c551ad8a8023", "nick", "1", "en", "nick@cs.sunyit.edu", "1", "1", "1", "1", "1", "1", "1", "default", "1", "default", "default", "1", NULL),
("6", "vanderjr", "163170e4eee8e95780f8fe152cefdee77f1a4fbdaea7c224fcda01192154fba5", "vanderjr", "1", "en", "vanderjr@cs.sunyit.edu", "1", "0", "0", "0", "0", "0", "0", "default", "1", "default", "default", "0", NULL);

